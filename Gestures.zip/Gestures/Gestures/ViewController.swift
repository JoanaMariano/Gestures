//
//  ViewController.swift
//  Gestures
//
//  Created by Joana on 04/09/2019.
//  Copyright © 2019 Joana. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var netRotation:CGFloat = 0
    
    @IBOutlet weak var image: UIImageView!
    
    override func viewDidLoad() {
        
        //ROTATION
        let rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(ViewController.rotateGesture(_:)))
        image.addGestureRecognizer(rotateGesture)
        
        //PINCH
        let pinchGesture:UIPinchGestureRecognizer =
            UIPinchGestureRecognizer(target: self, action: #selector(ViewController.pinchGesture(_:)))
        image.addGestureRecognizer(pinchGesture)
        
        //SWIPE
        let swipeGestureRight = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.respondToSwipeGesture(_:)))
        swipeGestureRight.direction = UISwipeGestureRecognizer.Direction.right
        image.addGestureRecognizer(swipeGestureRight)
        
        let swipeGestureDown = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.respondToSwipeGesture(_:)))
        swipeGestureDown.direction = UISwipeGestureRecognizer.Direction.down
        image.addGestureRecognizer(swipeGestureDown)
        
        let swipeGestureLeft = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.respondToSwipeGesture(_:)))
        swipeGestureLeft.direction = UISwipeGestureRecognizer.Direction.left
        image.addGestureRecognizer(swipeGestureLeft)
        
        let swipeGestureUp = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.respondToSwipeGesture(_:)))
        swipeGestureUp.direction = UISwipeGestureRecognizer.Direction.up
        image.addGestureRecognizer(swipeGestureUp)
        
        //TAPGESTURE
        let tapGesture = UITapGestureRecognizer(target: self, action:
            #selector(ViewController.handleTap(_:)))
        tapGesture.numberOfTapsRequired = 2;
        image.addGestureRecognizer(tapGesture)
        
        //LONG PRESS
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(ViewController.action(_:)))
        longPressGesture.minimumPressDuration = 2.0;
        image.addGestureRecognizer(longPressGesture)
        
        image.image = UIImage(named: "image1.png")
        
        super.viewDidLoad()
    }
    
    @IBAction func pinchGesture(_ sender : UIPinchGestureRecognizer) {
        
        let factor = sender.scale
        
        if (factor > 1) {
            //increase zoom
            sender.view?.transform = CGAffineTransform(
                scaleX: lastScaleFactor + (factor-1),
                y: lastScaleFactor + (factor-1));
        } else {
            //decrease zoom
            sender.view?.transform = CGAffineTransform(
                scaleX: lastScaleFactor * factor,
                y: lastScaleFactor * factor);
        }
        if (sender.state == UIGestureRecognizer.State.ended){
            if (factor > 1) {
                lastScaleFactor += (factor-1);
            } else {
                lastScaleFactor *= factor;
            }
            
        }
    }
    
    @IBAction func handleTap(_ sender : UIGestureRecognizer) {
        
        if (sender.view?.contentMode == UIView.ContentMode.scaleAspectFit){
            sender.view?.contentMode = UIView.ContentMode.center
        }
        else{
            sender.view?.contentMode = UIView.ContentMode.scaleAspectFit
        }
        
        print("Tap")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //ROTATION
    @IBAction func rotateGesture(_ sender : UIRotationGestureRecognizer) {
        let rotation:CGFloat = sender.rotation
        let transform:CGAffineTransform  =
            CGAffineTransform(rotationAngle: rotation + netRotation)
        sender.view?.transform = transform
        if (sender.state == UIGestureRecognizer.State.ended){
            netRotation += rotation;
        }
    }
    
    //SWIPE
    @IBAction func respondToSwipeGesture(_ send: UIGestureRecognizer) {
        
        if let swipeGesture = send as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                changeImage()
                print("Swiped right")
            case UISwipeGestureRecognizer.Direction.down:
                changeImage()
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                changeImage()
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                changeImage()
                print("Swiped up")
            default:
                break
            }
        }
    }
    
    //LONG PRESS
    @IBAction func action(_ gestureRecognizer:UIGestureRecognizer) {
        
        if (gestureRecognizer.state == UIGestureRecognizer.State.began){
            let alertController = UIAlertController(title: "Alert", message: "Long Press gesture", preferredStyle: .alert)
            let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in }
            alertController.addAction(OKAction)
            self.present(alertController, animated: true) { }
        }
    }
    
    func changeImage(){
        if (image.image == UIImage(named: "image1.png")){
            image.image = UIImage(named: "image2.png")}
        else{
            image.image = UIImage(named: "image1.png")
        }
    }
}

